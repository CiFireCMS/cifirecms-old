<?php
/**
 * - Ini adalah file konfigurasi instalasi komponen CiFireCMS.
 * - Komponen   : Buku Tamu
 * - Tanggal    : 2019-12-24 | 04:12 PM
*/

$_config['component_name']  = 'Buku Tamu';
$_config['class_name']      = 'buku_tamu';
$_config['table_name']      = 't_bukutamu';
$_config['file_sql']        = 't_bukutamu.sql';
$_config['file_controller'] = 'Buku_tamu.php';
$_config['file_model']      = 'Buku_tamu_model.php';
$_config['dir_views']       = 'buku-tamu';
$_config['file_modjs']      = 'buku-tamu.js';
$_config['mod']             = 'buku-tamu';
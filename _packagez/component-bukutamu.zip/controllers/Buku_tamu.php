<?php
/**
 * - This file was created using CoGen
 * 
 * - Date created : 2019-12-23 | 08:50
 * - Author       : CiFireCMS
 * - License      : MIT License
 * - Website      : https://www.alweak.com
*/

defined('BASEPATH') OR exit('No direct script access allowed');

class Buku_tamu extends Backend_controller {

	public $mod = 'buku-tamu';

	public function __construct() 
	{
		parent::__construct();
		
		$this->load->model("mod/buku_tamu_model");
		$this->meta_title("Buku Tamu");
	}


	public function index()
	{
		if ($this->read_access)
		{
			if ($this->input->is_ajax_request()) 
			{
				if ($this->input->post('act')=='delete') {
					return $this->_delete();
				}
				else
				{
					$data = array();

					foreach ($this->buku_tamu_model->datatable('_data', 'data') as $val) 
					{
						$row = [];
						// checkbox (all row)
						$row[] = '<div class="text-center"><input type="checkbox" class="row_data" value="'. encrypt($val['id']) .'"></div>';
						$row[] = $val['id'];
						$row[] = $val['nama'];
						$row[] = $val['telepon'];
						$row[] = '<div class="text-center"><div class="btn-group">
									<button type="button" onclick="location.href=\''. admin_url($this->mod."/edit/".$val['id']) .'\'" class="btn btn-xs btn-white" data-toggle="tooltip" data-placement="top" data-title="'. lang_line('button_edit') .'"><i class="cificon licon-edit"></i></button>
									<button type="button" class="btn btn-xs btn-white delete_single" data-toggle="tooltip" data-placement="top" data-title="'.lang_line('button_delete').'" data-pk="'. encrypt($val['id']) .'"><i class="cificon licon-trash-2"></i></button>
								</div></div>';
						$data[] = $row;
					} // endforeach.

					$this->json_output(['data' => $data, 'recordsFiltered' => $this->buku_tamu_model->datatable('_data', 'count')]);
				}

			}
			else
			{
				$this->render_view('view_index', $this->vars);
			}
		}
		else
		{
			show_403();
		}
	}


	public function add()
	{
		if ($this->write_access ) 
		{
			if ($_SERVER['REQUEST_METHOD'] == 'POST')
			{
				$this->form_validation->set_rules(array(array(
					'field' => 'nama',
					'label' => 'Nama',
					'rules' => 'trim'
				)));

				$this->form_validation->set_rules(array(array(
					'field' => 'telepon',
					'label' => 'Telepon',
					'rules' => 'trim'
				)));

				$this->form_validation->set_rules(array(array(
					'field' => 'komentar',
					'label' => 'Komentar'
				)));

				if ($this->form_validation->run())
				{
					$data_isert = array(
						'nama' => xss_filter($this->input->post('nama')),
						'telepon' => xss_filter($this->input->post('telepon')),
						'komentar' => xss_filter($this->input->post('komentar')),
					);

					if ($this->buku_tamu_model->insert($data_isert))
					{
						$this->alert->set($this->mod, 'info', 'Data has been successfully added');
						redirect(admin_url($this->mod),'refresh');
					}
					else
					{
						$this->alert->set($this->mod, 'danger', "Oups..! Some error occurred.<br>Please complete the data correctly");
					}
				}
			}
			else
			{
				$this->render_view('view_add', $this->vars);
			}
		}
		else
		{
			show_403();
		}
	}


	public function edit($id_data = '')
	{
		if ($this->modify_access)
		{
			$id_edit = xss_filter($id_data, 'sql');
			$cek_id = $this->buku_tamu_model->cek_id($id_edit);

			if ($cek_id == 1) 
			{
				if ($_SERVER['REQUEST_METHOD']=='POST')
				{
					$this->form_validation->set_rules(array(array(
						'field' => 'nama',
						'label' => 'Nama',
						'rules' => 'trim'
					)));

					$this->form_validation->set_rules(array(array(
						'field' => 'telepon',
						'label' => 'Telepon',
						'rules' => 'trim'
					)));

					$this->form_validation->set_rules(array(array(
						'field' => 'komentar',
						'label' => 'Komentar'
					)));

					if ( $this->form_validation->run() )
					{
						$data_update = array(

							'nama' => xss_filter($this->input->post('nama')),
							'telepon' => xss_filter($this->input->post('telepon')),
							'komentar' => xss_filter($this->input->post('komentar')),
						);

						if ($this->buku_tamu_model->update($id_edit, $data_update))
						{
							$this->alert->set($this->mod, 'info', 'Data has been successfully updated');
						}
						else
						{
							$this->alert->set($this->mod, 'danger', "Oups..! Some error occurred.<br>Please complete the data correctly");
						}
					}
				}
				$data_edit = $this->buku_tamu_model->get_data_edit($id_edit);
				$this->vars['data_row'] = $data_edit;
				$this->render_view('view_edit', $this->vars);
			}
			else
			{
				$this->render_404();
			}
		}
		else
		{
			$this->render_403();
		}
	}


	private function _delete()
	{
		if ($this->input->is_ajax_request() && $this->delete_access)
		{
			$data = $this->input->post('data');

			foreach ($data as $key)
			{
				$pk = xss_filter(decrypt($key),'sql');
				$this->buku_tamu_model->delete($pk);
			}

			$response['success'] = true;
			$this->json_output($response);
		}
		else
		{
			$response['success'] = false;
			$this->json_output($response);
		}
	}
} // End Class.
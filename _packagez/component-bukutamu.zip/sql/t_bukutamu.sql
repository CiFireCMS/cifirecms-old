#
# TABLE STRUCTURE FOR: t_bukutamu
#

DROP TABLE IF EXISTS `t_bukutamu`;

CREATE TABLE `t_bukutamu` (
  `id` int(50) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT '',
  `telepon` varchar(20) DEFAULT '',
  `komentar` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `t_bukutamu` (`id`, `nama`, `telepon`, `komentar`) VALUES (1, 'Bagong', '08123456789', 'Warung kopi');
INSERT INTO `t_bukutamu` (`id`, `nama`, `telepon`, `komentar`) VALUES (2, 'Chya', '082176453789', 'Komen saja asal te ba sogol.. ^_^');
INSERT INTO `t_bukutamu` (`id`, `nama`, `telepon`, `komentar`) VALUES (3, 'Nay', '082174638926', 'Arawenu yau??  :D');


